import streamlit as st
import pandas as pd

# Set the page title
st.title("Hello, World!")

# Add a header and some text
st.header("My First Streamlit App")
st.write("Welcome to your new dashboard. Streamlit makes data apps easy.")

# Add an interactive slider
number = st.slider("Select a value", 0, 100, 50)
st.write(f"You selected: {number}")

# Display a simple dataframe
data = {
    'Column A': [1, 2, 3, 4],
    'Column B': [10, 20, 30, 40]
}
df = pd.DataFrame(data)
st.subheader("Sample Data Table")
st.dataframe(df)

# Add a button
if st.button('Click Me'):
    st.balloons()
    st.success("You clicked the button!")